package oop.ex45;

public interface Element {
  void accept(Visitor v);
}
