package oop.ex21;

public class Ex2 {
  public void method3() {
    System.out.println(new Ex1().method2());
  }
}