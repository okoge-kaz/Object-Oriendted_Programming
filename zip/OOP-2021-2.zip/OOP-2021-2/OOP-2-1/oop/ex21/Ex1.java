package oop.ex21;

public class Ex1 {
  protected int field = 42;
  public char method1() { return '?'; }
  protected double method2() { return 0.1; }
}