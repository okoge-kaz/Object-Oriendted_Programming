package oop.ex24;

public interface Iterator {
  public int next();
}
