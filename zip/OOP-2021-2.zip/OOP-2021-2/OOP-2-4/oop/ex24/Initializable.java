package oop.ex24;

public interface Initializable {
  public void init(int n);
}
