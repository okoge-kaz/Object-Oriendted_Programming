package oop.ex25;

public interface Element {
  public abstract void print();
  public abstract void move(int dx, int dy);
}
