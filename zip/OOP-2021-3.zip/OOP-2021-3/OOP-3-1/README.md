# 問題3-1(基本)

`Main31`クラスには、第一引数の文字列が第二引数の配列内存在するかを確かめる`contains`メソッドが定義されている。
`main`メソッドを実行すると以下の実行例になるように`contains`メソッドを修正せよ。

<!-- リストの分け方および果物の選択は例題上の工夫以外の意図はない。 -->

## 実行例
    apple is in the list 1 : false
    apple is in the list 2 : true
    pineapple is in the list 1 : true
    pineapple is in the list 2 : false
    grapefruit is in the list 1 : false
    grapefruit is in the list 2 : true
    grape is in the list 1 : true
    grape is in the list 2 : false
