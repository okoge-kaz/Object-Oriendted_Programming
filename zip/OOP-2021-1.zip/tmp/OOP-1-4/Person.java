public class Person {
  // (1)
  String name = "name";
  // (2)
  public String getName() {
    return name;
  }
  // (3)
  public void setName(String name) {
    this.name = name;
  }
}