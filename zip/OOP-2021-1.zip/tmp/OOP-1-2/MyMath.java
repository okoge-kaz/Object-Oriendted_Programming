public class MyMath {
  public static final double E = 2.7182818284;
  public static double square(double x) {
    return x * x;
  }
}