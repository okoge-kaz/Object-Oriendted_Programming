class Main12 {
  public static void main(String[] args) {
    System.out.println("e = " + MyMath.E);
    System.out.printf("square(%f) = %f", -3.0, MyMath.square(-3.0));
    System.out.println(); // 改行
    System.out.printf("square(%f) = %f", 1.7320508, MyMath.square(1.7320508));
    System.out.println();
  }
}